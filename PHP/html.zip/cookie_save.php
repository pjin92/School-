<?
     setcookie("cookie_value",$irum);
?>
<script>location.href="cookie_view.php"</script>
