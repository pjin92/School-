function menu()
{
	var s_menu;

	s_menu="<table width='900' border='0' cellspacing='0' cellpadding='3'>" + "\n"
+ "    <tr> " + "\n"
+ "      <td bgcolor='#F7F7F7'>" + "\n"
+ "        <div align='center'> " + "\n"
+ "     <br><table width='780' border='0' cellspacing='0' cellpadding='0'>" + "\n"
+ "     <tr>" + "\n"
+ "        <td>" + "\n"
+ "          <div align='center'> " + "\n"
+ "            <table width='720' border='0' cellspacing='1' cellpadding='6' bgcolor='#CCCCCC'>" + "\n"
+ "              <tr> " + "\n"
+ "                <td bgcolor='#F2F2F2'> " + "\n"
+ "                  <div align='center'> " + "\n"
+ "                    <table width='660' border='0' cellspacing='0' cellpadding='2'>" + "\n"
+ "                      <tr> " + "\n"
+ "                        <td width='100'><font color='#0457A2'>�� </font><a href='member.php'><font color='#0457A2'>ȸ������</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>�� </font><a href='product.php'><font color='#0457A2'>��ǰ����</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>�� </font><a href='jumun.php'><font color='#0457A2'>�ֹ�����</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>�� </font><a href='opt.php'><font color='#0457A2'>�ɼǰ���</font></a></td>" + "\n"
+ "                        <td width='100'><font color='#0457A2'>�� </font><a href='faq.php'><font color='#0457A2'>FAQ����</font></a></td>" + "\n"
+ "                      </tr>" + "\n"
+ "                    </table>" + "\n"
+ "                  </div>" + "\n"
+ "                </td>" + "\n"
+ "              </tr>" + "\n"
+ "            </table>" + "\n"
+ "          </div>" + "\n"
+ "        </td>" + "\n"
+ "      </tr>" + "\n"
+ "    </table>" + "\n"
+ "        </div><br>" + "\n"
+ "      </td>" + "\n"
+ "    </tr>" + "\n"
+ "  </table>" + "\n"
+ "  <hr width='900' size='3'>" + "\n";

  return s_menu;
}

