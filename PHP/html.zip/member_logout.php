<?

			setcookie("cookie_no", "");
			setcookie("cookie_name", "");
		echo("<script> location.href = 'index.html' </script>");
			
			?>